export class Sala {
    nome: string;
    quantidade: number;
    computador: boolean = false;
    projetor: boolean = false;
    videoconferencia: boolean = false;
}
