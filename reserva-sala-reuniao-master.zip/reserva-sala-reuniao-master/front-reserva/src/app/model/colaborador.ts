export class Colaborador {
    nome: string;
    email: string;
    telefone: number;
}
